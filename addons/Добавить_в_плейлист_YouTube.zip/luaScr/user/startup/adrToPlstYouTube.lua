-- Дополнение для добавления текущего адреса видео (плейлиста) в группу "YouTube" https://www.youtube.com (5/3/21)
-- Copyright © 2017-2021 Nexterr |
-- необходим видеоскрипт: YT.lua
-- создайте в плейлисте SimpleTV в любой вкладке группу: YouTube
dofile (m_simpleTV.MainScriptDir .. 'user/adrToPlstYouTube/start.lua')