-- Дополнение для добавления текущего адреса видео (плейлиста) в группу "YouTube" https://www.youtube.com (5/3/21)
-- Copyright © 2017-2021 Nexterr |
-- необходим видеоскрипт: YT.lua
-- создайте в плейлисте SimpleTV в любой вкладке группу: YouTube
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	if not m_simpleTV.User.YT then
		m_simpleTV.User.YT = {}
	end
	htmlEntities = require 'htmlEntities'
	local function ShowMessage(s)
		local imageParam = 'vSizeFactor="0.5" src="'
						.. m_simpleTV.MainScriptDir_UTF8
						.. 'user/adrToPlstYouTube/Img/logo.png"'
		m_simpleTV.OSD.ShowMessageT({imageParam = imageParam, text = s, showTime = 1000 * 6, id = 'channelName'})
	end
	local function clean_adr(s)
			if not s then return end
		s = s:gsub('&is%a+=%a+', '')
		local index = s:match('&index=(%d+)')
		if index == '1' then
			s = s:gsub('&index=%d+', '')
		end
	 return s
	end
	local function unescape_html(str)
	 return htmlEntities.decode(str)
	end
	local function title_clean(s)
		s = s:gsub('%%22', '"')
		s = s:gsub('\\u0026', '&')
		s = s:gsub('\\u2060', '')
		s = s:gsub('\\u200b', '')
		s = s:gsub('\\n', ' ')
		s = s:gsub('\\\\', '\\')
		s = unescape_html(s)
		s = s:gsub('"', '\'')
	 return s
	end
	local function desc_clean(d)
		d = d:gsub('%%22', '"')
		d = d:gsub('\\u200%a', '')
		d = d:gsub('\\u202%a', '')
		d = d:gsub('\\u00ad', '')
		d = d:gsub('\\r', '')
		d = d:gsub('\r', '')
		d = d:gsub('\\n', '\n')
		d = d:gsub('\n\n[\n]+', '\n\n')
		d = unescape3(d)
		d = unescape_html(d)
		d = d:gsub('"', '\'')
	 return d
	end
	local function findChannelIdByAddress(adr)
		if adr then
			local t = m_simpleTV.Database.GetTable('SELECT Channels.Id FROM Channels WHERE Channels.Address="' .. adr .. '" AND Channels.Id<268435455;')
				if t and t[1] and t[1].Id then
				 return t[1].Id
				end
		end
	 return nil
	end
	function adrToPlstYouTube()
		local info = m_simpleTV.Control.GetCurrentChannelInfo()
			if not info or info.Id == - 1 then return end
			if not info.Address then return end
		if not info.MultiAddress then info.MultiAddress = '' end
			if not info.Address:match('^https?://[%a%.]*youtu[%.combe]')
				and not info.MultiAddress:match('^https?://[%a%.]*youtu[%.combe]')
				and not info.Address:match('^%s*%-')
			then
				ShowMessage('это не адрес YouTube')
			 return
			end
			if not (m_simpleTV.Control.GetState() == 3
				or m_simpleTV.Control.GetState() == 4)
				or not m_simpleTV.User.YT.vId
			then
				ShowMessage('не доступно')
			 return
			end
		local title, plst, pos, adr, logo, desc, GroupName
		if m_simpleTV.User.YT.isVideo == false then
			plst = true
		end
		if plst == true
			and m_simpleTV.User.YT.AddToBaseUrlinAdr
			and not findChannelIdByAddress(clean_adr(m_simpleTV.User.YT.AddToBaseUrlinAdr))
		then
			local t = {}
			t.message = 'добавить адрес\n【да】 - плейлиста\n【нет】 - видео'
			t.caption = 'YouTube'
			t.buttons = 'Yes|No|Cancel'
			t.icon    = 'Question'
			t.defButton = 'Cancel'
			local but = m_simpleTV.Interface.MessageBoxT(t)
			if but == 'Yes' then
				pos = 0
				title = m_simpleTV.User.YT.plstHeader
				adr = m_simpleTV.User.YT.AddToBaseUrlinAdr
				logo = 'https://i.ytimg.com/vi/' .. m_simpleTV.User.YT.AddToBaseVideoIdPlst .. '/hqdefault.jpg'
			end
			if but == 'No' then
				pos = (m_simpleTV.Control.GetPosition() or 0)
				title = m_simpleTV.User.YT.title
				adr = 'https://www.youtube.com/watch?v=' .. m_simpleTV.User.YT.vId
				logo = 'https://i.ytimg.com/vi/' .. m_simpleTV.User.YT.vId .. '/hqdefault.jpg'
				plst = false
			end
				if but == 'Cancel' then return end
		else
			pos = (m_simpleTV.Control.GetPosition() or 0)
			title = m_simpleTV.User.YT.title
			adr = 'https://www.youtube.com/watch?v=' .. m_simpleTV.User.YT.vId
			logo = 'https://i.ytimg.com/vi/' .. m_simpleTV.User.YT.vId .. '/hqdefault.jpg'
			plst = false
		end
		local extFilter = 0
		local groupId = 0
		local typeMedia = m_simpleTV.PlayList.GetMediaMode()
		title = title_clean(title)
		adr = clean_adr(adr)
		if plst == true then
			plst = 'плейлист'
			desc = ''
			GroupName = 'YouTube'
		else
			plst = 'видео'
			desc = m_simpleTV.User.YT.desc or ''
			desc = desc_clean(desc)
			GroupName = 'YouTube'
		end
		if GroupName ~= '' then
			local t = m_simpleTV.Database.GetTable('SELECT Channels.Id, Channels.ExtFilter,Channels.TypeMedia FROM Channels WHERE (Channels.Name="' .. GroupName .. '" AND Channels.Id>268435455);')
			if t and t[1] then
				groupId = (t[1].Id or 0)
				extFilter = (t[1].ExtFilter or 0)
				if t[1].TypeMedia then
					typeMedia = t[1].TypeMedia
				end
			end
		end
		local channelId = findChannelIdByAddress(adr)
		if channelId then
			local t = {}
			t.message = 'Видео с таким адресом существует, переписать?'
			t.caption = 'YouTube'
			t.buttons = 'Yes|No'
			t.icon    = 'Question'
			t.defButton = 'No'
				if m_simpleTV.Interface.MessageBoxT(t) == 'No' then return end
				if not m_simpleTV.Database.ExecuteSql('DELETE FROM Channels WHERE (Channels.Id=' .. channelId .. ');', true) then return end
		else
			t = m_simpleTV.Database.GetTable('SELECT (MAX(Channels.Id))+1 AS NewId FROM Channels WHERE Channels.Id<268435456 AND Channels.Id<>268435455;')
				if not t
					or not t[1]
					or not t[1].NewId
				then
				 return
				end
			channelId = t[1].NewId
		end
-- debug_in_file('id:' .. channelId .. '\ntitle:' .. title .. '\nadr:' .. adr .. '\ngr:' .. groupId .. '\nlogo:' .. logo .. '\npos:' .. pos .. '\nplst:' .. plst .. '\ndesc:' .. desc .. '\n')
		if m_simpleTV.Database.ExecuteSql('INSERT INTO Channels ([Id],[ChannelOrder],[Name],[Address],[Group],[Logo],[ExtFilter],[TypeMedia],[LastPosition],[Desc],[Title]) VALUES (' .. channelId .. ',' .. channelId .. ',"' .. title .. '","' .. adr .. '",' .. groupId .. ',"' .. logo .. '",' .. extFilter ..',' .. typeMedia .. ',' .. pos .. ',"' .. desc .. '","' .. plst .. '");')
		then
			title = 'ссылка на ' .. plst .. ' добавлена'
			ShowMessage(title)
			m_simpleTV.PlayList.Refresh()
		else
			title = 'не возможно добавить'
			ShowMessage(title)
		end
	end
	m_simpleTV.Interface.AddExtMenuT({
									name = 'Добавить в плейлист YouTube',
									luastring = 'adrToPlstYouTube()',
									lua_as_scr = true,
									ctrlkey = 2,
									key = 0x20,
									image = m_simpleTV.MainScriptDir_UTF8 .. 'user/adrToPlstYouTube/Img/menu.png'
									})
	m_simpleTV.Interface.AddExtMenuT({utf8 = false, name = '-'})